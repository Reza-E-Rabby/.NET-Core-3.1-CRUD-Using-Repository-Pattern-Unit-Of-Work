﻿using Microsoft.AspNetCore.Identity;

namespace GamersCommunity.Data.Models
{
    public class GcUser : IdentityUser
    {
    }
}
